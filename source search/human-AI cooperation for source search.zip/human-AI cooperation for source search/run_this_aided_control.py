import time
# import matplotlib.pyplot as plt
import tkinter as tk
from pylab import *
import numpy as np
import scipy.io as scio
import algorithm
import envdisplay
import winsound

UNIT = 25

t = 250
Q = 0.5
D = 1
V = 1
a = 1
X_min = 0
Y_min = 0
X_max = 20
Y_max = 20
particle_number = 2000
step_size = 1
size = 1

user = 'user'

class main(object):

    def __init__(self):
        #############
        # param #
        #######################################
        dataFile = './map_20.mat'
        data = scio.loadmat(dataFile)
        self.map_all = data['MAP_all']
        self.source_location = data['source_location']
        self.starting_location = data['starting_location']

        scenes_data = scio.loadmat('./' + user + '/scenes_order')
        self.scenes_order = scenes_data['ac_scenes']

        self.result = []
        self.success_num = 0
        self.episode = -1
        self.run_num = 10

        self.root = envdisplay.Maze()
        self.root.title('Aided control')
        self.root.canvas.bind("<Button-1>", self.cf_board)

        self.b_start = tk.Button(self.root.f_header, text="START", command=self.bf_start,
                                 font=("Times New Roman", 15, "bold"))
        self.b_start.place(x=5, y=10, anchor='nw')

        self.b_continue = tk.Button(self.root.f_header, text="CONTINUE", command=self.bf_continue,
                                      font=("Times New Roman", 15, "bold"))
        self.b_continue.place(x=5+5*UNIT, y=10, anchor='nw')

        self.b_execute = tk.Button(self.root.f_header, text="EXECUTE", command=self.bf_execute,
                                   font=("Times New Roman", 15, "bold"))
        self.b_execute.place(x=5+11*UNIT, y=10, anchor='nw')

        self.b_next = tk.Button(self.root.f_header, text="NEXT", command=self.bf_next,
                                   font=("Times New Roman", 15, "bold"))
        self.b_next.place(x=5+17*UNIT, y=10, anchor='nw')

        self.l_info = tk.Label(self.root.f_header, text="Click START to start the search process", width=50,
                               height=4, bg="white", font=("Times New Roman", 14), wraplength=18*UNIT)

        # self.l_info.pack(side='bottom', fill='both')
        self.l_info.place(x=5, y=60, anchor='nw')
        self.b_continue.config(state='disabled')
        self.b_execute.config(state='disabled')
        self.b_next.config(state='disabled')

        self.reset()
        self.root.mainloop()

    def reset(self):
        self.episode += 1
        self.scenes = self.scenes_order[0, self.episode]
        self.v_x = self.starting_location[self.scenes, 0]
        self.v_y = self.starting_location[self.scenes, 1]
        self.v_x = floor(self.v_x) + 0.5
        self.v_y = floor(self.v_y) + 0.5
        self.s_x = self.source_location[self.scenes, 0]
        self.s_y = self.source_location[self.scenes, 1]
        self.o_map = self.map_all[:, :, self.scenes]
        self.unknow_map = np.zeros((20, 20))

        self.trajectory = []
        self.de_up_zero = []
        self.particle = []
        self.result_in_episode = []
        self.is_forbidden = []
        self.result_flag = 0
        self.forbidden_flag = 0
        self.manual_flag = 0
        self.pf = algorithm.ParticleFilter()

        self.chosen_trajectory = np.array([int(floor(self.v_x / size)),
                                           int(floor(self.v_y / size))]).reshape(1, 2)
        self.draw_chosen_trajectory = []

        xy = np.vstack((self.pf.x, self.pf.y)).T
        self.particle.append(xy.tolist())
        self.trajectory.append(self.v_x*20+self.v_y)
        self.T_in_episode = 0
        self.root.draw_reset(self.v_x, self.v_y, self.s_x, self.s_y, self.o_map, self.pf.x, self.pf.y)
        self.update_unknown_area()
        self.root.canvas.update()
        self.human_control_record = []
        self.human_control_st = 0
        # self.b_time = time.time()
        # self.l_time = self.b_time
        self.already_flag = 0

    def update_unknown_area(self):
        vx = int(floor(self.v_x / size))
        vy = int(floor(self.v_y / size))
        for i in range(-1, 2):
            for j in range(-1, 2):
                x = self.v_x + i * step_size
                y = self.v_y + j * step_size
                if (x <= X_max) and (x >= X_min) and (y <= Y_max) and (y >= Y_min):
                    id = (vx + i * step_size) * 20 + vy + j * step_size
                    self.root.canvas.delete(self.root.unknown_area[id])
                    self.unknow_map[vx + i * step_size, vy + j * step_size] = 1

    def step(self):
        self.update_unknown_area()
        self.T_in_episode += 1
        if floor(self.v_x / size) == floor(self.s_x / size) and floor(self.v_y / size) == floor(self.s_y / size):
            self.l_info.config(text="The source has been found successfully!", fg='red')
            self.root.canvas.create_oval(UNIT * self.s_x - 6, UNIT * self.s_y - 6,
                                         UNIT * self.s_x + 6, UNIT * self.s_y + 6, fill='red')
            self.root.canvas.update()
            self.success_num += 1
            self.result_flag = 1
            self.result.append([self.T_in_episode, self.starting_location[self.scenes, 0],
                                self.starting_location[self.scenes, 1], self.s_x, self.s_y, self.result_flag])
            self.save_result()
            self.b_next.config(state='normal')
            return

        if self.T_in_episode > 400:
            self.l_info.config(text="The search mission is fail!", fg='red')
            self.result_flag = -1
            self.result.append([self.T_in_episode, self.starting_location[self.scenes, 0],
                                self.starting_location[self.scenes, 1], self.s_x, self.s_y, self.result_flag])
            self.b_next.config(state='normal')
            self.save_result()
            return

        self.detection = np.random.poisson(algorithm.diff(self.v_x, self.v_y, self.s_x, self.s_y, a, Q, V, D, t))

        self.root.draw_detection(self.detection, self.v_x, self.v_y)

        self.pf.update(self.v_x, self.v_y, self.detection)
        neff = 1 / sum(np.square(self.pf.weight))
        if neff < 1 * particle_number:
            self.pf.resample()
            self.pf.mcmcStep(self.v_x, self.v_y, self.detection)

        is_forbidden_flag = algorithm.if_forbidden(self.v_x, self.v_y, self.o_map)
        if is_forbidden_flag:
            self.is_forbidden.extend([1])
            self.o_map[int(floor(self.v_x / size)), int(floor(self.v_y / size))] = -1
            self.root.draw_fb(self.v_x, self.v_y)
        else:
            self.is_forbidden.extend([0])

        I = algorithm.infotaixs(self.v_x, self.v_y, self.pf)
        # I = np.random.uniform(100, 200, 4)
        II = algorithm.I2II(self.v_x, self.v_y, self.o_map, I)
        want_action = argmin(I)
        self.real_action = argmin(II)
        self.root.draw_action(self.v_x, self.v_y, want_action, self.real_action)

        return

    def bf_algorithm_step(self):
        self.b_continue.config(state='disabled')
        self.b_execute.config(state='disabled')
        self.b_next.config(state='disabled')
        while True:
            self.step()
            if self.result_flag == 0:
                # self.PC, self.manual_flag = algorithm.if_manual(self.T_in_episode, self.PC, self.action)
                self.manual_flag = algorithm.if_manual(self.T_in_episode, self.trajectory)

                if self.manual_flag == 1:
                    self.chosen_trajectory = np.array([int(floor(self.v_x / size)),
                                                       int(floor(self.v_y / size))]).reshape(1, 2)
                    self.draw_chosen_trajectory = []
                    self.b_execute.config(state='disable')
                    self.root.draw_update(self.v_x, self.v_y, self.o_map, self.pf.x, self.pf.y)
                    self.l_info.config(text="The searcher has been trapped. "
                                            "Please select and click a Passable area (white area), "
                                            "then click EXECUTE to help it escape")

                    mean_x, mean_y = algorithm.obtain_cluster(self.pf.x, self.pf.y)
                    self.root.canvas.create_oval(UNIT * mean_x - 30, UNIT * mean_y - 30,
                                                 UNIT * mean_x + 30, UNIT * mean_y + 30, outline='salmon',
                                                 dash=(3, 5), width=2, tag='mean_xy')
                    winsound.Beep(1000, 1500)
                    self.human_control_st = time.time()
                    return

                if self.real_action == 0:
                    self.v_x += step_size
                elif self.real_action == 1:
                    self.v_y += step_size
                elif self.real_action == 2:
                    self.v_x -= step_size
                elif self.real_action == 3:
                    self.v_y -= step_size

                self.root.draw_update(self.v_x, self.v_y, self.o_map, self.pf.x, self.pf.y)
                print('episode', self.episode, 'scenes', self.scenes,
                      'success_num', self.success_num, 'T', self.T_in_episode)
                xy = np.vstack((self.pf.x, self.pf.y)).T
                self.particle.append(xy.tolist())
                self.trajectory.append(self.v_x*20+self.v_y)
                self.result_in_episode.append([self.episode, self.T_in_episode,
                                               time.time()-self.l_time, self.v_x, self.v_y, self.detection, 0])
                self.l_time = time.time()

            else:
                if self.episode > self.run_num-2:
                    self.l_info.config(text="All search missions have been completed!", fg='red')
                    self.b_next.config(state='disabled')
                return

    def cf_board(self, e):
        if self.manual_flag == 1 and self.already_flag == 0:
            x_now, y_now = self.obtain_area(e)
            x_last = self.chosen_trajectory[-1, 0]
            y_last = self.chosen_trajectory[-1, 1]
            if self.o_map[x_now, y_now] == 1 and self.unknow_map[x_now, y_now] == 1:
                myAstar = algorithm.AStar((x_last, y_last), (x_now, y_now), self.o_map, self.unknow_map)
                if myAstar.run() == 1:
                    routelist = myAstar.get_minroute()
                    self.b_continue.config(state='disabled')
                    self.b_execute.config(state='normal')
                    self.chosen_trajectory = np.array(routelist)

                    for i in range(1, len(routelist)):
                        dct = self.root.canvas.create_rectangle(routelist[i][0] * UNIT, routelist[i][1] * UNIT,
                                                                  (routelist[i][0]+1)*UNIT, (routelist[i][1]+1)*UNIT,
                                                                  outline="cadetblue", width=2, tag='ct')
                        self.draw_chosen_trajectory.append(dct)
                        self.root.canvas.update()
                    self.l_info.config(text="Click the EXECUTE to execute the search process")
                    self.already_flag = 1
                else:
                    print('路径规划失败！')

            # if abs(x_now - x_last) + abs(y_now - y_last) == 1:
            #     if self.o_map[x_now, y_now] == 1 and self.unknow_map[x_now, y_now] == 1:
            #
            #         self.b_continuous.config(state='disabled')
            #         self.chosen_trajectory = np.vstack((self.chosen_trajectory,
            #                                             np.array([x_now, y_now]).reshape(1, 2)))
            #         dct = self.root.canvas.create_rectangle(x_now*UNIT, y_now*UNIT,
            #                                           (x_now+1)*UNIT, (y_now+1)*UNIT,
            #                                           outline="black", width=2, activefill='skyblue',
            #                                           activestipple="gray50", tag='ct')
            #         self.draw_chosen_trajectory.append(dct)
            #         self.root.canvas.update()
            # else:
            #     print('wrong area')

    def obtain_area(self, e):
        x = int(floor(e.x / size / UNIT))
        y = int(floor(e.y / size / UNIT))
        return x, y

    def bf_continue(self):
        self.human_control_record.append([self.T_in_episode, self.human_control_st, time.time(),
                                          time.time() - self.human_control_st, 2])  # 1:execute, 2:continue
        self.l_info.config(text="Algorithm is controlling the search process")
        self.root.canvas.delete('mean_xy')
        if self.real_action == 0:
            self.v_x += step_size
        elif self.real_action == 1:
            self.v_y += step_size
        elif self.real_action == 2:
            self.v_x -= step_size
        elif self.real_action == 3:
            self.v_y -= step_size

        self.root.draw_update(self.v_x, self.v_y, self.o_map, self.pf.x, self.pf.y)
        print('episode', self.episode, 'scenes', self.scenes,
              'success_num', self.success_num, 'T', self.T_in_episode)
        xy = np.vstack((self.pf.x, self.pf.y)).T
        self.particle.append(xy.tolist())
        self.trajectory.append(self.v_x*20+self.v_y)
        self.result_in_episode.append([self.episode, self.T_in_episode,
                                       time.time() - self.l_time, self.v_x, self.v_y, self.detection, 0])
        self.l_time = time.time()
        self.bf_algorithm_step()

    def bf_start(self):
        self.b_start.config(state='disabled')
        self.l_info.config(text="Algorithm is controlling the search process")
        self.b_time = time.time()
        self.l_time = self.b_time
        self.result_in_episode.append([self.episode, self.T_in_episode,
                                       self.b_time, self.v_x, self.v_y,
                                       0, 0])  # detection, Flag of Human(1) or Algorithm(0)
        self.bf_algorithm_step()

    def bf_execute(self):
        if len(self.draw_chosen_trajectory) > 0:
            self.already_flag = 0
            self.human_control_record.append([self.T_in_episode, self.human_control_st, time.time(),
                                              time.time()-self.human_control_st, 1])  # 1:execute, 2:continue
            self.root.canvas.delete('mean_xy')
            self.b_execute.config(state='disabled')
            self.l_info.config(text="Human is controlling the search process")
            for i in range(len(self.draw_chosen_trajectory)):
                v_x = int(floor(self.v_x / size))
                v_y = int(floor(self.v_y / size))

                vx = self.chosen_trajectory[i+1, 0]
                vy = self.chosen_trajectory[i+1, 1]

                dct = self.draw_chosen_trajectory[i]
                self.root.canvas.delete(dct)

                if vx - v_x == 1:
                    self.v_x += step_size
                elif vy - v_y == 1:
                    self.v_y += step_size
                elif vx - v_x == -1:
                    self.v_x -= step_size
                elif vy - v_y == -1:
                    self.v_y -= step_size

                self.root.draw_update(self.v_x, self.v_y, self.o_map, self.pf.x, self.pf.y)
                print('episode', self.episode, 'scenes', self.scenes,
                      'success_num', self.success_num, 'T', self.T_in_episode)
                xy = np.vstack((self.pf.x, self.pf.y)).T
                self.particle.append(xy.tolist())
                self.trajectory.append(self.v_x*20+self.v_y)
                self.result_in_episode.append([self.episode, self.T_in_episode,
                                               time.time() - self.l_time, self.v_x, self.v_y, self.detection, 1])
                self.l_time = time.time()
                self.step()
                if self.result_flag != 0:
                    # self.l_info.config(text="Algorithm is controlling the search process")
                    # self.bf_algorithm_step()
                    # self.b_execute.config(state='normal')
                    return

            self.draw_chosen_trajectory = []
            self.chosen_trajectory = np.array([int(floor(self.v_x / size)),
                                               int(floor(self.v_y / size))]).reshape(1, 2)

            self.b_continue.config(state='normal')
            self.b_execute.config(state='normal')
            mean_x, mean_y = algorithm.obtain_cluster(self.pf.x, self.pf.y)
            self.root.canvas.create_oval(UNIT * mean_x - 30, UNIT * mean_y - 30,
                                         UNIT * mean_x + 30, UNIT * mean_y + 30, outline='salmon',
                                         dash=(3, 5), width=2, tag='mean_xy')

            self.l_info.config(text="Please select another Passable area or "
                                    "click the CONTINUE to allow algorithm to continue to control the search process")
            self.human_control_st = time.time()
        else:
            print('hhhhh')

    def bf_next(self):
        if self.episode > self.run_num-2:
            self.l_info.config(text="All search missions have been completed!", fg='red')
            return

        self.reset()
        self.l_info.config(text="Algorithm is controlling the search process", fg='black')
        self.b_time = time.time()
        self.l_time = self.b_time
        self.result_in_episode.append([self.episode, self.T_in_episode,
                                       self.b_time, self.v_x, self.v_y,
                                       0, 0])  # detection, Flag of Human(1) or Algorithm(0)
        self.bf_algorithm_step()

    def save_result(self):
        dataNew = './'+user+'/AC-scenes' + str(self.scenes) + '.mat'
        scio.savemat(dataNew, {'source_location': [self.s_x, self.s_y],
                               'result': self.result_in_episode,
                               'scenes': self.scenes,
                               'human_control_record': self.human_control_record})


if __name__ == "__main__":
    main()




