import tkinter as tk
# from run_this import *
from PIL import Image, ImageTk
from pylab import *

UNIT = 25
X_min = 0
Y_min = 0
X_max = 20
Y_max = 20
size = 1
step_size = 1


class Maze(tk.Tk, object):
    def __init__(self):
        super(Maze, self).__init__()

        self.configure(bg="#CDC0B0")
        # self.resizable(width=False, height=False)
        self.f_header = tk.Frame(self, height=6 * UNIT, width=X_max * UNIT, highlightthickness=0, bg="#CDC0B0")
        self.f_header.place(x=10, y=20.5*UNIT, anchor='nw')

        self.geometry('{0}x{1}'.format((X_max+11) * UNIT, (Y_max+7) * UNIT))

        self.canvas = tk.Canvas(self, height=Y_max * UNIT, width=X_max * UNIT, bg='white')
        self.canvas.place(x=10, y=10, anchor='nw')

        # self.legend = tk.Canvas(self, height=Y_max * UNIT + 95, width=190, bg='white')
        # self.draw_legend()
        img_open = Image.open('Legend.jpg')
        self.img_png = ImageTk.PhotoImage(img_open)
        self.legend = tk.Label(self, image=self.img_png, height=Y_max * UNIT + 150, width=240, bg='white')
        self.legend.place(x=20 + X_max * UNIT, y=10, anchor='nw')

        # self.canvas.update()

    # def draw_legend(self):
        # title = tk.Label(self.legend, text='Legend', bg="white", font=("Times New Roman", 14, "bold"))
        # title.place(x=60, y=6, anchor='nw')
        #
        # x = 10
        # y = 35
        # passable_area = self.legend.create_rectangle(x, y, x+UNIT, y+UNIT, fill='#808080', width=0)

    def draw_reset(self, v_x, v_y, s_x, s_y, o_map, x, y):

        self.canvas.delete("all")

        self.r_action = self.canvas.create_oval(0, 0, 1, 1, fill='red')
        self.w_action = self.canvas.create_oval(0, 0, 1, 1, fill='red')

        self.map_area = self.canvas.create_rectangle(2, 2, X_max * UNIT, Y_max * UNIT, outline='black')
        self.unknown_area = []
        for i in range(20):
            for j in range(20):
                if o_map[i, j] == 0:
                    self.canvas.create_rectangle(i*UNIT, j*UNIT, (i+1)*UNIT, (j+1)*UNIT, fill='#808080', width=0)

                ua = self.canvas.create_rectangle(i * UNIT, j * UNIT, (i + 1) * UNIT, (j + 1) * UNIT,
                                                       fill='black', width=0)
                self.unknown_area.append(ua)

        self.draw_particle(x, y)
        self.v_position = self.canvas.create_oval(UNIT * v_x - 4, UNIT * v_y - 4,
                                                  UNIT * v_x + 4, UNIT * v_y + 4, outline='blue')

        self.init_position = self.canvas.create_oval(UNIT * v_x - 6, UNIT * v_y - 6,
                                                     UNIT * v_x + 6, UNIT * v_y + 6, fill='blue')
        # self.s_position = self.canvas.create_oval(UNIT * s_x - 6, UNIT * s_y - 6,
        #                                           UNIT * s_x + 6, UNIT * s_y + 6, fill='red')

        self.lastpoint = [v_x, v_y]

        # self.update_unknown_area(v_x, v_y)
        # self.canvas.update()

    def update_unknown_area(self, v_x, v_y):
        vx = int(floor(v_x / size))
        vy = int(floor(v_y / size))

        for i in range(-1, 2):
            for j in range(-1, 2):
                x = v_x + i*step_size
                y = v_y + j*step_size
                if (x <= X_max) and (x >= X_min) and (y <= Y_max) and (y >= Y_min):
                    id = (vx + i*step_size) * 20 + vy + j*step_size
                    self.canvas.delete(self.unknown_area[id])
                    # self.canvas.update()

    def draw_particle(self, x, y):
        particle_size = 2
        for i in range(len(x)):
            self.canvas.create_oval(x[i]*UNIT - particle_size, y[i]*UNIT - particle_size,
                                    x[i]*UNIT + particle_size, y[i]*UNIT + particle_size,
                                    outline='green', tag='part')
        # self.canvas.update()

    def draw_detection(self, z, v_x, v_y):
        if z > 0:
            # self.canvas.create_oval(UNIT * v_x - 4, UNIT * v_y - 4, UNIT * v_x + 4, UNIT * v_y + 4, fill='red')
            self.canvas.create_rectangle(UNIT * v_x - 4, UNIT * v_y - 4,
                                         UNIT * v_x + 4, UNIT * v_y + 4, fill='Magenta', tag='tar')
        else:
            self.canvas.create_oval(UNIT * v_x - 2, UNIT * v_y - 2,
                                    UNIT * v_x + 2, UNIT * v_y + 2, fill='Magenta', tag='tar')

    def draw_update(self, v_x, v_y, o_map, x, y):
        self.canvas.delete('part')
        self.canvas.delete(self.v_position)

        self.draw_particle(x, y)
        self.canvas.create_line(UNIT * self.lastpoint[0], UNIT * self.lastpoint[1], UNIT * v_x, UNIT * v_y, tag='tar')

        self.v_position = self.canvas.create_oval(UNIT * v_x - 6, UNIT * v_y - 6,
                                                  UNIT * v_x + 6, UNIT * v_y + 6, outline='blue', tag='tar')
        self.canvas.tag_raise('tar')
        self.lastpoint = [v_x, v_y]
        self.canvas.update()

    def draw_fb(self, x, y):
        i = int(floor(x/size))
        j = int(floor(y/size))
        self.canvas.create_rectangle(i * UNIT, j * UNIT, (i + 1) * UNIT, (j + 1) * UNIT,
                                     fill='#B4B4B4', width=0, tag='fb')
        self.canvas.tag_lower('fb')
        # self.canvas.update()

    def draw_action(self, v_x, v_y, want_action, real_action):
        self.canvas.delete(self.r_action)
        self.canvas.delete(self.w_action)

        x1 = 10
        x2 = 6

        if real_action == 0:
            self.r_action = self.canvas.create_polygon((UNIT * (v_x + step_size) + x1, UNIT * v_y,
                                        UNIT * (v_x + step_size), UNIT * v_y + x2,
                                        UNIT * (v_x + step_size), UNIT * v_y - x2), fill='red', tag='tar')
        elif real_action == 1:
            self.r_action = self.canvas.create_polygon((UNIT * v_x, UNIT * (v_y + step_size) + x1,
                                        UNIT * v_x + x2, UNIT * (v_y + step_size),
                                        UNIT * v_x - x2, UNIT * (v_y + step_size)), fill='red', tag='tar')
        elif real_action == 2:
            self.r_action = self.canvas.create_polygon((UNIT * (v_x - step_size) - x1, UNIT * v_y,
                                                        UNIT * (v_x - step_size), UNIT * v_y + x2,
                                                        UNIT * (v_x - step_size), UNIT * v_y - x2), fill='red', tag='tar')
        elif real_action == 3:
            self.r_action = self.canvas.create_polygon((UNIT * v_x, UNIT * (v_y - step_size) - x1,
                                                        UNIT * v_x + x2, UNIT * (v_y - step_size),
                                                        UNIT * v_x - x2, UNIT * (v_y - step_size)), fill='red', tag='tar')
        if want_action == real_action:
            self.canvas.update()
            return

        if want_action == 0:
            self.w_action = self.canvas.create_polygon((UNIT * (v_x + step_size) + x1, UNIT * v_y,
                                        UNIT * (v_x + step_size), UNIT * v_y + x2,
                                        UNIT * (v_x + step_size), UNIT * v_y - x2), fill='blue', tag='tar')
        elif want_action == 1:
            self.w_action = self.canvas.create_polygon((UNIT * v_x, UNIT * (v_y + step_size) + x1,
                                        UNIT * v_x + x2, UNIT * (v_y + step_size),
                                        UNIT * v_x - x2, UNIT * (v_y + step_size)), fill='blue', tag='tar')
        elif want_action == 2:
            self.w_action = self.canvas.create_polygon((UNIT * (v_x - step_size) - x1, UNIT * v_y,
                                                        UNIT * (v_x - step_size), UNIT * v_y + x2,
                                                        UNIT * (v_x - step_size), UNIT * v_y - x2), fill='blue', tag='tar')
        elif want_action == 3:
            self.w_action = self.canvas.create_polygon((UNIT * v_x, UNIT * (v_y - step_size) - x1,
                                                        UNIT * v_x + x2, UNIT * (v_y - step_size),
                                                        UNIT * v_x - x2, UNIT * (v_y - step_size)), fill='blue', tag='tar')
        self.canvas.update()


if __name__ == "__main__":
    ma = Maze()
    # ma.draw_map(o_map)

    ma.mainloop()



